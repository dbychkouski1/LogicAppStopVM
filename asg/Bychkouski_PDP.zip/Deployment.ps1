﻿function Connect-AZURE() {
    #Connect with Azure

    $clientID = "f92d98be-06a3-4ae4-8b23-39e9c7d1f1a0"
    $key = "jNevkwN4LsbBpqo5qHXaPO8ASQX2+HS9gKs8+H/lSg0="
    $SecurePassword = $key | ConvertTo-SecureString -AsPlainText -Force
    $cred = new-object -typename System.Management.Automation.PSCredential `
        -argumentlist $clientID, $SecurePassword
    $tenantID = "546a2d5b-e66c-476c-91fc-010da4e06b9c"
    Add-AzureRmAccount -Credential $cred -TenantId $tenantID -ServicePrincipal
    $subID = "d44df320-a45f-4c85-a870-4ff0a789595c"
    Select-AzureRmSubscription -SubscriptionId $subID
    (Get-AzureRmContext).Subscription
    try {
        [Microsoft.Azure.Common.Authentication.AzureSession]::ClientFactory.AddUserAgent("VSAzureTools-$UI$($host.name)".replace(' ', '_'), '3.0.0')
    }
    catch { }
}

Connect-AZURE


$login = "Azureuser"
Write-Host(" >>>>>>>>>>login for Vms: $login<<<<<<<<<<<<<")
Write-Host(">>>>>>>>>>>enter password for VMs<<<<<<<<<<<<")
$VMpassword = read-host -AsSecureString

New-AzureRmResourceGroup -Name ResourceGroup-A -Location 'West Europe'
New-AzureRmResourceGroup -Name ResourceGroup-B -Location 'West Europe'
#############################################################################
#Deployment VNet and NSG
$VNETTemplate = (Get-ChildItem VNET.json).Fullname 
New-AzureRmResourceGroupDeployment -ResourceGroupName ResourceGroup-A -TemplateFile  $VNETTemplate -Verbose
$VNET = (Get-AzureRmVirtualNetwork).Id
$SubnetID = "$vnet" + "/subnets" + "/Subnet1"
$NSG = (Get-AzureRmNetworkSecurityGroup).id



#ResourceGroup-A deployment 2 VM
$VMTemplate = (Get-ChildItem VMs.json).Fullname  
New-AzureRmResourceGroupDeployment -ResourceGroupName ResourceGroup-A -TemplateFile  $VMtemplate -Verbose `
    -virtualMachineAdminUserName $login `
    -virtualMachineAdminPassword $VMpassword `
    -virtualMachineCount 2 `
    -SubnetID $SubnetID `
    -virtualMachineNamePrefix 'vmA' `
    -NSGID $NSG
   
#ResourceGroup-B deployment 2 VM
New-AzureRmResourceGroupDeployment -ResourceGroupName ResourceGroup-B -TemplateFile  $VMtemplate -Verbose `
    -virtualMachineAdminUserName $login `
    -virtualMachineAdminPassword $VMpassword `
    -virtualMachineCount 2 `
    -SubnetID $SubnetID `
    -virtualMachineNamePrefix 'vmB' `
    -NSGID $NSG
 
 




$RulesTemplate = (Get-ChildItem Rules.json).Fullname  
$A1 = Get-AzureRmApplicationSecurityGroup -ResourceGroupName ResourceGroup-A| where {$_.name -like "*1"}
$A2 = Get-AzureRmApplicationSecurityGroup -ResourceGroupName ResourceGroup-A| where {$_.name -like "*2"}
$B1 = Get-AzureRmApplicationSecurityGroup -ResourceGroupName ResourceGroup-B| where {$_.name -like "*1"}
$B2 = Get-AzureRmApplicationSecurityGroup -ResourceGroupName ResourceGroup-B| where {$_.name -like "*2"}

New-AzureRmResourceGroupDeployment -ResourceGroupName ResourceGroup-A -TemplateFile  $RulesTemplate -Verbose `
    -A1 $A1.id `
    -A2 $A2.id `
    -B1 $B1.id `
    -B2 $B2.id 



